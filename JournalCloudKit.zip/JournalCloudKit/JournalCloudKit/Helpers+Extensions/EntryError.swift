//
//  EntryError.swift
//  JournalCloudKit
//
//  Created by Michael Nguyen on 12/7/20.
//

import Foundation
import CloudKit

enum EntryError: LocalizedError {
    case ckError(Error)
    case couldNotUnwrap
    
    var errorDescription: String {
        switch self {
        case .ckError(let error):
            return error.localizedDescription
        case .couldNotUnwrap:
            return "Could not get the entry"
        }
    }
}
