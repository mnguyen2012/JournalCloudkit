//
//  EntryController.swift
//  JournalCloudKit
//
//  Created by Michael Nguyen on 12/7/20.
//

import Foundation
import CloudKit

class EntryController {
    static let shared = EntryController()
    
    var entries : [Entry] = []
    
    let privateDB = CKContainer.default().privateCloudDatabase
    
    func createEntry(with title: String, body: String, completion: @escaping (_ result: Result<Entry?, EntryError>) -> Void) {
        let newEntry = Entry(title: title, body: body)
        saveEntry(with: newEntry, completion: completion)
    }
    
    func saveEntry(with entry: Entry, completion: @escaping(_ result: Result<Entry?, EntryError>) -> Void) {
        let entryRecord = CKRecord(entry: entry)
        privateDB.save(entryRecord) { (record, error) in
            if let error = error {
                print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
                return completion(.failure(.ckError(error)))
            }
            guard let record = record,
                  let savedEntry = Entry(ckRecord: record)
            else { return completion(.failure(.couldNotUnwrap))}
            print("Entry successfully saved")
            self.entries.insert(savedEntry, at: 0)
                  completion(.success(savedEntry))
        }
    }
    func fetchEntries(completion: @escaping (Result<[Entry], EntryError>) -> Void) {
        
        let predicate = NSPredicate(value: true)
        let query = CKQuery(recordType: EntryConstants.recordTypeKey, predicate: predicate)
        privateDB.perform(query, inZoneWith: nil) { (records, error) in
            if let error = error {
                print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
                completion(.failure(.ckError(error)))
            }
            guard let records = records else { return completion(.failure(.couldNotUnwrap)) }
            print("Fetch all entries successful")
            let entries = records.compactMap({ Entry(ckRecord: $0) })
            self.entries = entries
            completion(.success(entries))
        }
    }
}
